from sklearn.cluster import KMeans
import numpy as np
import csv
import math
import matplotlib.pyplot
from matplotlib import pyplot as plt
import pandas as pd

maxAcc = 0.0
maxIter = 0
C_Lambda = 0.03
TrainingPercent = 80
ValidationPercent = 10
TestPercent = 10
M = 10
PHI = []
IsSynthetic = False

# This function reads a .csv file and output the file data in an t[] array
def GetTargetVector(filePath):
    t = []
    with open(filePath, 'rU') as f:
        reader = csv.reader(f)
        for row in reader:
            t.append(int(row[0]))
    # print("Raw Training Generated..")
    return t

# This function reads a .csv file and output the file in an dataMatrix[] array
def GenerateRawData(filePath, IsSynthetic):
    dataMatrix = []
    with open(filePath, 'rU') as fi:
        reader = csv.reader(fi)
        for row in reader:
            dataRow = []
            for column in row:
                dataRow.append(float(column))
            dataMatrix.append(dataRow)

    # By changing IsSynthetic boolean value, we can decide whether to include the feature column 5, 6, 7, 8, 9
    # Noticing that feature column 5, 6, 7, 8, 9 in the Dataset is all 0 value
    # We delete the value of the feature column 5, 6, 7, 8, 9 at this point to aviod the zero value
    if IsSynthetic == False:
        dataMatrix = np.delete(dataMatrix, [5, 6, 7, 8, 9], axis=1)
    dataMatrix = np.transpose(dataMatrix)
    # print ("Data Matrix Generated..")
    return dataMatrix

# Generating the Training Target: 80% of total
def GenerateTrainingTarget(rawTraining, TrainingPercent=80):
    TrainingLen = int(math.ceil(len(rawTraining) * (TrainingPercent * 0.01)))
    t = rawTraining[:TrainingLen]
    # print(str(TrainingPercent) + "% Training Target Generated..")
    return t

# Generating the Training Data: 80% of total
def GenerateTrainingDataMatrix(rawData, TrainingPercent=80):
    T_len = int(math.ceil(len(rawData[0]) * 0.01 * TrainingPercent))
    d2 = rawData[:, 0:T_len]
    # print(str(TrainingPercent) + "% Training Data Generated..")
    return d2

# Generating Validation Data: 10% of total
def GenerateValData(rawData, ValPercent, TrainingCount):
    valSize = int(math.ceil(len(rawData[0]) * ValPercent * 0.01))
    V_End = TrainingCount + valSize
    dataMatrix = rawData[:, TrainingCount + 1:V_End]
    # print (str(ValPercent) + "% Val Data Generated..")
    return dataMatrix

# Generating Validation Target Data: 10% of total
def GenerateValTargetVector(rawData, ValPercent, TrainingCount):
    valSize = int(math.ceil(len(rawData) * ValPercent * 0.01))
    V_End = TrainingCount + valSize
    t = rawData[TrainingCount + 1:V_End]
    # print (str(ValPercent) + "% Val Target Data Generated..")
    return t

# Generating Big Sigma for later calculating
def GenerateBigSigma(Data, MuMatrix, TrainingPercent, IsSynthetic):
    BigSigma = np.zeros((len(Data), len(Data)))
    DataT = np.transpose(Data)
    TrainingLen = math.ceil(len(DataT) * (TrainingPercent * 0.01))
    varVect = []
    for i in range(0, len(DataT[0])):
        vct = []
        for j in range(0, int(TrainingLen)):
            vct.append(Data[i][j])
        varVect.append(np.var(vct))

    for j in range(len(Data)):
        BigSigma[j][j] = varVect[j]
    if IsSynthetic == True:
        BigSigma = np.dot(3, BigSigma)
    else:
        BigSigma = np.dot(200, BigSigma)
    ##print ("BigSigma Generated..")
    return BigSigma


def GetScalar(DataRow, MuRow, BigSigInv):
    R = np.subtract(DataRow, MuRow)
    T = np.dot(BigSigInv, np.transpose(R))
    L = np.dot(R, T)
    return L


def GetRadialBasisOut(DataRow, MuRow, BigSigInv):
    phi_x = math.exp(-0.5 * GetScalar(DataRow, MuRow, BigSigInv))
    return phi_x

# Generating the design Matrix
def GetPhiMatrix(Data, MuMatrix, BigSigma, TrainingPercent=80):
    DataT = np.transpose(Data)
    TrainingLen = math.ceil(len(DataT) * (TrainingPercent * 0.01))
    PHI = np.zeros((int(TrainingLen), len(MuMatrix)))
    BigSigInv = np.linalg.inv(BigSigma)
    for C in range(0, len(MuMatrix)):
        for R in range(0, int(TrainingLen)):
            PHI[R][C] = GetRadialBasisOut(DataT[R], MuMatrix[C], BigSigInv)
    # print ("PHI Generated..")
    return PHI

# Calculating the weight
def GetWeightsClosedForm(PHI, T, Lambda):
    Lambda_I = np.identity(len(PHI[0]))
    for i in range(0, len(PHI[0])):
        Lambda_I[i][i] = Lambda
    PHI_T = np.transpose(PHI)
    PHI_SQR = np.dot(PHI_T, PHI)
    PHI_SQR_LI = np.add(Lambda_I, PHI_SQR)
    PHI_SQR_INV = np.linalg.inv(PHI_SQR_LI)
    INTER = np.dot(PHI_SQR_INV, PHI_T)
    W = np.dot(INTER, T)
    ##print ("Training Weights Generated..")
    return W

# Same function as the above, generating the design Matrix
def GetPhiMatrix(Data, MuMatrix, BigSigma, TrainingPercent=80):
    DataT = np.transpose(Data)
    TrainingLen = math.ceil(len(DataT) * (TrainingPercent * 0.01))
    PHI = np.zeros((int(TrainingLen), len(MuMatrix)))
    BigSigInv = np.linalg.inv(BigSigma)
    for C in range(0, len(MuMatrix)):
        for R in range(0, int(TrainingLen)):
            PHI[R][C] = GetRadialBasisOut(DataT[R], MuMatrix[C], BigSigInv)
    # print ("PHI Generated..")
    return PHI


def GetValTest(VAL_PHI, W):
    Y = np.dot(W, np.transpose(VAL_PHI))
    ##print ("Test Out Generated..")
    return Y

# Calculating the accuracy and Erms
# put the accuracy and Erms in an array at index 0 and 1, seperating by ','
def GetErms(VAL_TEST_OUT, ValDataAct):
    sum = 0.0
    t = 0
    accuracy = 0.0
    counter = 0
    val = 0.0
    for i in range(0, len(VAL_TEST_OUT)):
        sum = sum + math.pow((ValDataAct[i] - VAL_TEST_OUT[i]), 2)
        if (int(np.around(VAL_TEST_OUT[i], 0)) == ValDataAct[i]):
            counter += 1
    accuracy = (float((counter * 100)) / float(len(VAL_TEST_OUT)))
    ##print ("Accuracy Generated..")
    ##print ("Validation E_RMS : " + str(math.sqrt(sum/len(VAL_TEST_OUT))))
    return (str(accuracy) + ',' + str(math.sqrt(sum / len(VAL_TEST_OUT))))

RawTarget = GetTargetVector('Querylevelnorm_t.csv')
RawData   = GenerateRawData('Querylevelnorm_X.csv',IsSynthetic)

TrainingTarget = np.array(GenerateTrainingTarget(RawTarget,TrainingPercent))
TrainingData   = GenerateTrainingDataMatrix(RawData,TrainingPercent)
print(TrainingTarget.shape)
print(TrainingData.shape)

ValDataAct = np.array(GenerateValTargetVector(RawTarget,ValidationPercent, (len(TrainingTarget))))
ValData    = GenerateValData(RawData,ValidationPercent, (len(TrainingTarget)))
print(ValDataAct.shape)
print(ValData.shape)

TestDataAct = np.array(GenerateValTargetVector(RawTarget,TestPercent, (len(TrainingTarget)+len(ValDataAct))))
TestData = GenerateValData(RawData,TestPercent, (len(TrainingTarget)+len(ValDataAct)))
print(ValDataAct.shape)
print(ValData.shape)




# Closed Form Solution
M_List = []
E_Train = []
E_Valid = []
E_Test = []
Acc_Train = []
Acc_Valid = []
Acc_Test = []

# I use an for loop to help me better collect all the data
for x in range (600,1001,20):
    C_Lambda = x/100
    M_List.append(str(C_Lambda))
    kmeans = KMeans(n_clusters=10, random_state=0).fit(np.transpose(TrainingData))
    Mu = kmeans.cluster_centers_

    # Calculating the elements
    BigSigma     = GenerateBigSigma(RawData, Mu, TrainingPercent,IsSynthetic)
    TRAINING_PHI = GetPhiMatrix(RawData, Mu, BigSigma, TrainingPercent)
    W            = GetWeightsClosedForm(TRAINING_PHI,TrainingTarget,(C_Lambda))
    TEST_PHI     = GetPhiMatrix(TestData, Mu, BigSigma, 100)
    VAL_PHI      = GetPhiMatrix(ValData, Mu, BigSigma, 100)

    #print(Mu.shape)
    #print(BigSigma.shape)
    #print(TRAINING_PHI.shape)
    #print(W.shape)
   # print(VAL_PHI.shape)
   # print(TEST_PHI.shape)

    TR_TEST_OUT  = GetValTest(TRAINING_PHI,W)
    VAL_TEST_OUT = GetValTest(VAL_PHI,W)
    TEST_OUT     = GetValTest(TEST_PHI,W)

    #sort in array
    TrainingAccuracy   = str(GetErms(TR_TEST_OUT,TrainingTarget))
    ValidationAccuracy = str(GetErms(VAL_TEST_OUT,ValDataAct))
    TestAccuracy       = str(GetErms(TEST_OUT,TestDataAct))

    Acc_Train.append(str(float(TrainingAccuracy.split(',')[0])))
    Acc_Valid.append(str(float(ValidationAccuracy.split(',')[0])))
    Acc_Test.append(str(float(TestAccuracy.split(',')[0])))
    E_Train.append(str(float(TrainingAccuracy.split(',')[1])))
    E_Valid.append(str(float(ValidationAccuracy.split(',')[1])))
    E_Test.append(str(float(TestAccuracy.split(',')[1])))


print ('UBITname      = Keming Kuang')
print ('Person Number = 50161776')
print ('----------------------------------------------------')
print ("------------------LeToR Data------------------------")
print ('----------------------------------------------------')
print ("-------Closed Form with Radial Basis Function-------")
print ('----------------------------------------------------')



for y in range (0,len(M_List)):

    print ("M = {}".format(M) + " \nLambda = {}".format(C_Lambda))
    print ("Training Accuracy   = " + str(Acc_Train[y]) + "        E_rms Training   = " + str(E_Train[y]))
    print ("Validation Accuracy = " + str(Acc_Valid[y]) + "         E_rms Validation = " + str(E_Valid[y]))
    print ("Testing Accuracy    = " + str(Acc_Test[y]) + "        E_rms Testing    = " + str(E_Test[y]))

# a code ised for data collection stored in .cvs
df = pd.DataFrame(data={"C_Lambda": M_List, "Training Accuracy": Acc_Train, "Validation Accuracy": Acc_Valid,
                        "Testing Accuracy": Acc_Test, "E_training": E_Train, "E_validation": E_Valid,
                        "E_testing": E_Test})
df.to_csv("Sample_List.csv", sep=',',index = False)



# Stochastic Gradient Decent
La = 2
learningRate = 0.01
L_Erms_Val = []
L_Erms_TR = []
L_Erms_Test = []
L_Acc_Val = []
L_Acc_TR = []
L_Acc_Test = []
L_Cluster = []
List_ETR_TR = []
List_ETR_Val = []
List_ETR_Test = []
List_Acc_TR = []
List_Acc_Val = []
List_Acc_Test = []
W_Mat = []



kmeans = KMeans(n_clusters=10, random_state=0).fit(np.transpose(TrainingData))
Mu = kmeans.cluster_centers_

# Calculating the elements
BigSigma     = GenerateBigSigma(RawData, Mu, TrainingPercent,IsSynthetic)
TRAINING_PHI = GetPhiMatrix(RawData, Mu, BigSigma, TrainingPercent)
W            = GetWeightsClosedForm(TRAINING_PHI,TrainingTarget,(C_Lambda))
TEST_PHI     = GetPhiMatrix(TestData, Mu, BigSigma, 100)
VAL_PHI      = GetPhiMatrix(ValData, Mu, BigSigma, 100)


print ('----------------------------------------------------')
print ('--------------Please Wait for 2 mins!----------------')
print ('----------------------------------------------------')


# I use an for loop to help me better collect all the data
for L_index in range(100,301):
    #La = L_index
    #learningRate=L_index/100
    iteration = L_index

    L_Cluster.append(str(L_index))

    W_Now = np.dot(220, W)

    #Training data with iterations, every iteration it updates its weights and biases.
    for i in range(0, iteration):
        # print ('---------Iteration: ' + str(i) + '--------------')
        Delta_E_D = -np.dot((TrainingTarget[i] - np.dot(np.transpose(W_Now), TRAINING_PHI[i])), TRAINING_PHI[i])
        La_Delta_E_W = np.dot(La, W_Now)
        Delta_E = np.add(Delta_E_D, La_Delta_E_W)
        Delta_W = -np.dot(learningRate, Delta_E)
        W_T_Next = W_Now + Delta_W
        W_Now = W_T_Next

        # -----------------TrainingData Accuracy---------------------#
        TR_TEST_OUT = GetValTest(TRAINING_PHI, W_T_Next)
        Erms_TR = GetErms(TR_TEST_OUT, TrainingTarget)
        L_Erms_TR.append(float(Erms_TR.split(',')[1]))
        L_Acc_TR.append(float(Erms_TR.split(',')[0]))


        # -----------------ValidationData Accuracy---------------------#
        VAL_TEST_OUT = GetValTest(VAL_PHI, W_T_Next)
        Erms_Val = GetErms(VAL_TEST_OUT, ValDataAct)
        L_Erms_Val.append(float(Erms_Val.split(',')[1]))
        L_Acc_Val.append(float(Erms_Val.split(',')[0]))


        # -----------------TestingData Accuracy---------------------#
        TEST_OUT = GetValTest(TEST_PHI, W_T_Next)
        Erms_Test = GetErms(TEST_OUT, TestDataAct)
        L_Erms_Test.append(float(Erms_Test.split(',')[1]))
        L_Acc_Test.append(float(Erms_Test.split(',')[0]))


    List_ETR_TR.append(str(np.around(min(L_Erms_TR), 5)))
    List_Acc_TR.append(str(L_Acc_TR[-1]))
    List_ETR_Val.append(str(np.around(min(L_Erms_Val), 5)))
    List_Acc_Val.append(str(L_Acc_Val[-1]))
    List_ETR_Test.append(str(np.around(min(L_Erms_Test), 5)))
    List_Acc_Test.append(str(L_Acc_Test[-1]))

for z in range(0,len(L_Cluster)):

    print('----------Gradient Descent Solution--------------------')
    print ("M = {}".format(10) + "\nLambda  = {}".format(La) + "\neta={}".format(learningRate))
    print ("E_rms Training   = " + str(List_ETR_TR[z]))
    print ("E_rms Validation = " + str(List_ETR_Val[z]))
    print ("E_rms Testing    = " + str(List_ETR_Test[z]))
    print ("Accuracy Training   = " + str(List_Acc_TR[z]))
    print ("Accuracy Validation   = " + str(List_Acc_Val[z]))
    print ("Accuracy Testing   = " + str(List_Acc_Test[z]))


# a code ised for data collection stored in .cvs
df = pd.DataFrame(data={"Iteraation": L_Cluster, "Training Accuracy": List_Acc_TR, "Validation Accuracy": List_Acc_Val, "Testing Accuracy": List_Acc_Test,"E_training": List_ETR_TR, "E_validation": List_ETR_Val, "E_testing": List_ETR_Test})
df.to_csv("Sample_L_List.csv", sep=',',index = False)